$oldPrefix = "V:\PC-Games\"
$newPrefix = "C:\PC-Games\"

$searchPath = "C:\roms\windows\"

$dryRun = $FALSE

$shell = new-object -com wscript.shell

if ( $dryRun ) {
   write-host "Executing dry run" -foregroundcolor green -backgroundcolor black
} else {
   write-host "Executing real run" -foregroundcolor red -backgroundcolor black
}

dir $searchPath -filter *.lnk -recurse | foreach {
   $lnk = $shell.createShortcut( $_.fullname )
   $oldPath= $lnk.targetPath
   $oldWorkDir= $lnk.WorkingDirectory
   $oldIconDir= $lnk.IconLocation

   $lnkRegex = "^" + [regex]::escape( $oldPrefix ) 

   if ( $oldPath -match $lnkRegex ) {
      $newPath = $oldPath -replace $lnkRegex, $newPrefix
	  $newWorkDir = $oldWorkDir -replace $lnkRegex, $newPrefix
	  $newIconDir = $oldIconDir -replace $lnkRegex, $newPrefix

      write-host "Found: " + $_.fullname -foregroundcolor yellow -backgroundcolor black
      write-host " Replace: " + $oldPath
      write-host " With:    " + $newPath

      if ( !$dryRun ) {
         $lnk.targetPath = $newPath
		 $lnk.WorkingDirectory = $newWorkDir
		 $lnk.IconLocation = $newIconDir
         $lnk.Save()
      }
   }
}
