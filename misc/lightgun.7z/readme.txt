Lightgun setup for Virtualman Retro-Bliss Level-Up 2.4.x
========================================================
IMPORTANT: not all games and systems work properly with all lightguns, but this method ensures both device type and key bindings are enforced on game launch.

Contents:
 - This Readme file.
 - *** To extract at V:\ *** , Retrobat folder with updated Lightgun collection, Retroarch game overrides and game remaps 
 - Lightgun resources namely:
	- Updated gamelists for all systems, with per-game emulator defined for lightgun games emulated by Retroarch cores.
	- Excel file with the emulator choices if you prefer to do them manually.
	- Simplified manual for the Mayflash Dolphinbar 
	
Notes: 
 1) This setup was tested and produced entirely using Mayflash Dolphinbar in Mode 2.
	Game remaps should be entirely reusable by other lightgun devices, but keybindings in game overrides might needs to be edited and adjusted according to your preferences.
    For the Wii you need to use Mode 4, please check Dolphin emulator documentation, not in scope for this document. 
	
Example:
Game override in V:\RetroBat\emulators\retroarch\config\FinalBurn Neo\spacegun.cfg
input_player1_a_mbtn = "2"
input_player1_b_mbtn = "1"
input_player1_gun_aux_a_mbtn = "2"
input_player1_gun_offscreen_shot_mbtn = "2"
input_player1_gun_trigger_mbtn = "1"
input_player1_gun_select = "escape"
input_player1_select = "escape"
input_player1_gun_start = "enter"
input_player1_start = "enter"

Game remap in V:\RetroBat\emulators\retroarch\config\remaps\FinalBurn Neo\spacegun.rmp
input_libretro_device_p1 = "4"  (code varies depending on emulator, defines emulated device type e.g. NES Zapper, MD Light Phaser)
input_libretro_device_p2 = "1"
input_libretro_device_p3 = "1"
input_libretro_device_p4 = "1"
input_libretro_device_p5 = "1"
input_player2_analog_dpad_mode = "0"
input_player3_analog_dpad_mode = "0"
input_player4_analog_dpad_mode = "0"
input_player5_analog_dpad_mode = "0"

To do new game remaps in Retroarch:
From a game, Quick Menu / Controls / Port 1 Controls (or Port 2 for SNES and Genesis), change device type to the appropriate lightgun device (depends on system)
Press Back, Save Game Remap File 
***NOTE***: Do not set core or content directory remaps else all your games get mapped as lightgun!

To enable access to game overrides in Retroarch:
Quick Menu, press Back, Settings / User Interface / Menu Item Visibility / Quick Menu, enable both Show Core and Show Game Overrides

To use game overrides afterwards:
From a game, Quick Menu / Overrides / Save Game Overrides
***NOTE***: your input settings do not get saved with game overrides, but they are loaded if added manually.

To define manually your controls and find your lightgun mouse/key bindings:
From Retroarch directly (not from a game), Settings / Input / Port 1 Controls
***NOTE 1***: ignore "Save Controller Profile" as it will get overwritten on next game launch, rely on this only to find your key bindings!
***NOTE 2***: it should save retroarch.cfg on exit but you can explicitly save from Main Menu / Configuration File / Save Current Configuration



